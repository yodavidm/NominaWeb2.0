package es.david.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.david.dao.*;
import es.david.model.*;

@WebServlet(description = "administra peticiones para la tabla empleados", urlPatterns = { "/empleados" })
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String opcion = request.getParameter("opcion");
		String contentPage = "";
		boolean activador1 = false;

		switch (opcion) {
			case "crear":
				System.out.println("Usted ha presionado la opcion crear");
				contentPage = "/views/crear.jsp";
				break;
			case "listar":
				EmpleadoDao empleadoDao = new EmpleadoDao();
				List<Empleado> lista = new ArrayList<>();
				try {
					lista = empleadoDao.obtenerEmpleados();
					for (Empleado empleado : lista) {
						System.out.println(empleado.getNombre());
					}

					request.setAttribute("lista", lista);
					contentPage = "/views/listar.jsp";
				} catch (SQLException | DatosNoCorrectosException e) {
					e.printStackTrace();
				}
				System.out.println("Usted ha presionado la opcion listar");
				break;
			case "editar":
				String dni = (request.getParameter("id"));
				System.out.println("Editar dni: " + dni);
				EmpleadoDao empleadoDaoEditar = new EmpleadoDao();
				Empleado empleadoEditar = new Empleado();

				try {
					empleadoEditar = empleadoDaoEditar.obtenerEmpleado(dni);
					System.out.println(empleadoEditar);
					request.setAttribute("empleado", empleadoEditar);
					contentPage = "/views/editar.jsp";
				} catch (SQLException | DatosNoCorrectosException e) {
					e.printStackTrace();
				}
				break;
			case "eliminar":
				EmpleadoDao empleadoDaoEliminar = new EmpleadoDao();
				String dniEliminar = (request.getParameter("id"));
				try {
					empleadoDaoEliminar.eliminar(dniEliminar);
					System.out.println("Registro eliminado satisfactoriamente...");
					activador1 = true;
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "buscarPorDni":
				System.out.println("Usted ha presionado la opcion buscarPorDni");
				contentPage = "/views/buscar.jsp";
				break;
			case "buscarEmpleados":
				contentPage = "/views/buscarEmpleados.jsp";
				break;
			default:
				
				break;
		}
		
		if(!activador1) {
			request.setAttribute("content", contentPage);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
			dispatcher.forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String opcion = request.getParameter("opcion");
		String contentPage = "";
		boolean activador = false;

		switch (opcion) {
			case "guardar":
				EmpleadoDao empleadoDaoGuardar = new EmpleadoDao();
				Empleado empleadoGuardar = new Empleado();
				empleadoGuardar.setDni(request.getParameter("dni"));
				empleadoGuardar.setNombre(request.getParameter("nombre"));
				empleadoGuardar.setSexo(request.getParameter("sexo"));
				try {
					empleadoGuardar.setCategoria(Integer.parseInt(request.getParameter("categoria")));
				} catch (NumberFormatException | DatosNoCorrectosException e) {
					e.printStackTrace();
				}
				empleadoGuardar.setAnyos(Integer.parseInt(request.getParameter("anyos")));
				try {
					empleadoDaoGuardar.guardar(empleadoGuardar);
					System.out.println("Registro guardado satisfactoriamente...");
					activador = true;
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "editar":
				Empleado empleadoEditar = new Empleado();
				EmpleadoDao empleadoDaoEditar = new EmpleadoDao();

				empleadoEditar.setDni(request.getParameter("dni"));
				empleadoEditar.setNombre(request.getParameter("nombre"));
				empleadoEditar.setSexo(request.getParameter("sexo"));
				try {
					empleadoEditar.setCategoria(Integer.parseInt(request.getParameter("categoria")));
				} catch (DatosNoCorrectosException e) {
					e.printStackTrace();
				}
				empleadoEditar.setAnyos(Integer.parseInt(request.getParameter("anyos")));
				try {
					empleadoDaoEditar.editar(empleadoEditar);
					RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
					dispatcher.forward(request, response);
					activador = true;
				} catch (SQLException e) {
					e.printStackTrace();
				}
				break;
			case "buscarPorDni":
				System.out.println("usted ha presionado buscar en POST");
				EmpleadoDao empleadoDaoBuscar = new EmpleadoDao();
				String dniBuscar = request.getParameter("dni");
				Nomina nomina = new Nomina();

				try {
					Empleado empleadoBuscar = empleadoDaoBuscar.obtenerEmpleado(dniBuscar);

					if (empleadoBuscar != null) {
						double salario = nomina.sueldo(empleadoBuscar);

						request.setAttribute("dni", empleadoBuscar.getDni());
						request.setAttribute("nombre", empleadoBuscar.getNombre());
						request.setAttribute("sexo", empleadoBuscar.getSexo());
						request.setAttribute("categoria", empleadoBuscar.getCategoria());
						request.setAttribute("anyos", empleadoBuscar.getAnyos());
						request.setAttribute("salario", salario);

						contentPage = "/views/salario.jsp";
					} else {
						request.setAttribute("error", "No se encontró el empleado con el DNI: " + dniBuscar);
						contentPage = "/views/error.jsp";
					}
				} catch (DatosNoCorrectosException | SQLException e) {
					e.printStackTrace();
				}
				break;
			case "buscarEmpleados":
				String campo = request.getParameter("campo");
				String valor = request.getParameter("valor");

				EmpleadoDao empleadoDaoBuscarEmpleados = new EmpleadoDao();

				try {
					List<Empleado> lista = empleadoDaoBuscarEmpleados.obtenerEmpleadosPorCampo(campo, valor);

					if (!lista.isEmpty()) {
						request.setAttribute("lista", lista);
						contentPage = "/views/listaEmpleados.jsp";
					} else {
						request.setAttribute("error",
								"No se encontraron empleados con el campo " + campo + " igual a " + valor);
						contentPage = "/views/error.jsp";
					}
				} catch (DatosNoCorrectosException | SQLException e) {
					e.printStackTrace();
				}
				break;
			default:
				
				break;
		}

		if(!activador) {
			request.setAttribute("content", contentPage);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
			dispatcher.forward(request, response);
		}
;
	}

}